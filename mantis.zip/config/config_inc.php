<?php
$g_default_language = 'english';
    $g_hostname = '127.0.0.1';
    $g_db_type = 'mysqli';
    $g_database_name = 'u798723837_GU1Yy';
    $g_db_username = 'u798723837_eGaUD';
    $g_db_password = 'NTLsNLMPu8';
    $g_db_table_prefix = 'ce6f';
    $g_crypto_master_salt = 't5ragfbojbbfndesdfmwcruyilqi8txz';
    $g_window_title	= 'Demo Bug Tracking System';
?>